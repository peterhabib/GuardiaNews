package com.example.gaurdianews;

import java.util.Date;

public class News {

    private String mWebTitle;
    private String mSectionName;
    private String mAuthorName;
    private Date mPublicationDate;
    private String mUrl;

    public News(String webTitle, String sectionName, String authorName, Date publicationDate, String url) {
        mWebTitle = webTitle;
        mSectionName = sectionName;
        mAuthorName = authorName;
        mPublicationDate = publicationDate;
        mUrl = url;
    }

    public String getWebTitle() {
        return mWebTitle;
    }

    public String getSectionName() {
        return mSectionName;
    }

    public String getAuthorName() {
        return mAuthorName;
    }

    public Date getPublicationDate() {
        return mPublicationDate;
    }

    public String getUrl() {
        return mUrl;
    }
}
